package me.shadorc.discordbot.exceptions;

public class RelicActivationException extends Exception {

	private static final long serialVersionUID = 1L;

	public RelicActivationException(String message) {
		super(message);
	}

}
